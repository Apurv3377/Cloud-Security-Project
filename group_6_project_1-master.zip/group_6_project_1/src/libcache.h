

const void* address_of_string(int choice);
void fetch_string(void *target, int choice, int size);

